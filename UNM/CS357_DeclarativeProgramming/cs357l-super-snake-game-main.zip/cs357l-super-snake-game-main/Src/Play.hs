module Main 
  (
    main
  ) where

import Game

main :: IO ()
main = do