module Main where

import Game
import TitleScreen

main :: IO ()
main = titleScreen
